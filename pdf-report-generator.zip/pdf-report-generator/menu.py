"""
Interactive terminal menu for PDF Report Generator.
Requires: pip install rich
"""

import os
import sys
import time
import subprocess
from typing import Optional

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.prompt import Prompt, Confirm, IntPrompt
    from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
    from rich.columns import Columns
    from rich.text import Text
    from rich.rule import Rule
    from rich.align import Align
    from rich import box
    from rich.live import Live
    from rich.padding import Padding
    from rich.style import Style
    from rich.markup import escape
except ImportError:
    print("\n[ERROR] 'rich' library not found.")
    print("Install it with:  pip install rich\n")
    sys.exit(1)

console = Console()

# ─── Themes ──────────────────────────────────────────────────────────────────

THEMES = {
    "1": {"name": "Ocean",    "primary": "#1a3c5e", "secondary": "#2e86c1", "accent": "#f39c12", "icon": "🌊"},
    "2": {"name": "Forest",   "primary": "#1b4332", "secondary": "#52b788", "accent": "#f77f00", "icon": "🌿"},
    "3": {"name": "Crimson",  "primary": "#2d1b2e", "secondary": "#c0392b", "accent": "#f39c12", "icon": "🔴"},
    "4": {"name": "Slate",    "primary": "#1c1c2e", "secondary": "#7c3aed", "accent": "#10b981", "icon": "💜"},
    "5": {"name": "Midnight", "primary": "#0f0f1a", "secondary": "#e91e63", "accent": "#00bcd4", "icon": "🌙"},
}

# ─── Config state ─────────────────────────────────────────────────────────────

config = {
    "data_file":  "",
    "output":     "report.pdf",
    "title":      "Annual Sales Report 2024",
    "subtitle":   "Q1–Q4 Performance Overview",
    "author":     "Sales Analytics Team",
    "company":    "Acme Corporation",
    "label_col":  "month",
    "bar_col":    "revenue",
    "line_cols":  "revenue expenses profit",
    "max_rows":   50,
    "primary":    "#1a3c5e",
    "secondary":  "#2e86c1",
    "accent":     "#f39c12",
    "demo":       False,
}

# ─── Helpers ─────────────────────────────────────────────────────────────────

def clear():
    os.system("cls" if os.name == "nt" else "clear")


def header():
    clear()
    console.print()
    title_text = Text()
    title_text.append("  ██████╗ ██████╗ ███████╗    \n", style="bold #2e86c1")
    title_text.append("  ██╔══██╗██╔══██╗██╔════╝    \n", style="bold #2e86c1")
    title_text.append("  ██████╔╝██║  ██║█████╗      \n", style="bold #5dade2")
    title_text.append("  ██╔═══╝ ██║  ██║██╔══╝      \n", style="bold #5dade2")
    title_text.append("  ██║     ██████╔╝██║         \n", style="bold #aed6f1")
    title_text.append("  ╚═╝     ╚═════╝ ╚═╝         \n", style="bold #aed6f1")

    subtitle = Text("  PDF Report Generator  ·  Powered by ReportLab", style="italic #7f8c8d")

    console.print(Align.center(title_text))
    console.print(Align.center(subtitle))
    console.print(Rule(style="#1a3c5e"))
    console.print()


def status_bar():
    """Show current config summary at the top."""
    tbl = Table(box=box.SIMPLE, show_header=False, padding=(0, 2), expand=True)
    tbl.add_column(justify="left",  style="#7f8c8d", no_wrap=True)
    tbl.add_column(justify="left",  style="white",   no_wrap=True)
    tbl.add_column(justify="left",  style="#7f8c8d", no_wrap=True)
    tbl.add_column(justify="left",  style="white",   no_wrap=True)

    src = "[bold green]demo[/]" if config["demo"] else (escape(config["data_file"]) or "[red]none[/]")
    tbl.add_row("Source",  src,
                "Output",  escape(config["output"]))
    tbl.add_row("Title",   escape(config["title"][:40]),
                "Author",  escape(config["author"]))

    panel = Panel(tbl, title="[bold #f39c12]Current Config[/]",
                  border_style="#2e86c1", padding=(0, 1))
    console.print(panel)
    console.print()


def build_command() -> str:
    parts = ["python report_generator.py"]
    if config["demo"]:
        parts.append("--demo")
    elif config["data_file"]:
        parts.append(f'"{config["data_file"]}"')
    else:
        parts.append("sales_data.csv")

    parts += [
        f'-o "{config["output"]}"',
        f'-t "{config["title"]}"',
    ]
    if config["subtitle"]:  parts.append(f'-s "{config["subtitle"]}"')
    if config["author"]:    parts.append(f'--author "{config["author"]}"')
    if config["company"]:   parts.append(f'--company "{config["company"]}"')
    if config["label_col"]: parts.append(f'--label-column {config["label_col"]}')
    if config["bar_col"]:   parts.append(f'--bar-column {config["bar_col"]}')
    if config["line_cols"]: parts.append(f'--line-columns {config["line_cols"]}')
    parts.append(f'--max-rows {config["max_rows"]}')
    parts.append(f'--primary-color "{config["primary"]}"')
    parts.append(f'--secondary-color "{config["secondary"]}"')
    parts.append(f'--accent-color "{config["accent"]}"')

    return " \\\n    ".join(parts)


def show_command():
    cmd = build_command()
    console.print(Panel(
        f"[bold #a8d4f0]{cmd}[/]",
        title="[bold #f39c12]Generated Command[/]",
        border_style="#2e86c1",
        padding=(1, 2),
    ))


def loading_animation(message: str, duration: float = 2.0):
    with Progress(
        SpinnerColumn(spinner_name="dots", style="#2e86c1"),
        TextColumn(f"[bold #5dade2]{message}"),
        BarColumn(bar_width=30, style="#1a3c5e", complete_style="#2e86c1", finished_style="#27ae60"),
        TextColumn("[#7f8c8d]{task.percentage:>3.0f}%"),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task("", total=100)
        steps = 40
        for i in range(steps + 1):
            time.sleep(duration / steps)
            progress.update(task, completed=(i / steps) * 100)


def success_box(msg: str):
    console.print(Panel(
        f"[bold green]✓[/]  {msg}",
        border_style="green", padding=(0, 2)
    ))


def error_box(msg: str):
    console.print(Panel(
        f"[bold red]✕[/]  {msg}",
        border_style="red", padding=(0, 2)
    ))


def info_box(msg: str):
    console.print(Panel(
        f"[bold #5dade2]ℹ[/]  {msg}",
        border_style="#2e86c1", padding=(0, 2)
    ))


# ─── Sub-menus ───────────────────────────────────────────────────────────────

def menu_data_source():
    header()
    console.print(Panel(
        "[bold]Select your data source[/]",
        border_style="#2e86c1", padding=(0,2)
    ))
    console.print()

    console.print("  [bold #f39c12][1][/]  Use built-in demo  [dim](sales_data.csv)[/]")
    console.print("  [bold #f39c12][2][/]  Enter CSV file path")
    console.print("  [bold #f39c12][3][/]  Enter JSON file path")
    console.print("  [bold #7f8c8d][0][/]  Back")
    console.print()

    choice = Prompt.ask("  [bold #2e86c1]Choose[/]", choices=["0","1","2","3"], default="1")

    if choice == "1":
        config["demo"] = True
        config["data_file"] = ""
        success_box("Demo mode enabled — will use sales_data.csv")
    elif choice in ("2", "3"):
        config["demo"] = False
        ext = "CSV" if choice == "2" else "JSON"
        path = Prompt.ask(f"  [bold #2e86c1]Enter {ext} file path[/]")
        if os.path.isfile(path):
            config["data_file"] = path
            if not config["output"] or config["output"] == "report.pdf":
                base = os.path.splitext(os.path.basename(path))[0]
                config["output"] = base + "_report.pdf"
            success_box(f"File set: {path}")
        else:
            error_box(f"File not found: {path}")
    time.sleep(1.2)


def menu_report_details():
    header()
    console.print(Panel("[bold]Report Details[/]", border_style="#2e86c1", padding=(0,2)))
    console.print()

    config["title"]    = Prompt.ask("  [#7f8c8d]Title   [/]", default=config["title"])
    config["subtitle"] = Prompt.ask("  [#7f8c8d]Subtitle[/]", default=config["subtitle"])
    config["author"]   = Prompt.ask("  [#7f8c8d]Author  [/]", default=config["author"])
    config["company"]  = Prompt.ask("  [#7f8c8d]Company [/]", default=config["company"])
    config["output"]   = Prompt.ask("  [#7f8c8d]Output  [/]", default=config["output"])

    console.print()
    success_box("Report details updated.")
    time.sleep(1.0)


def menu_chart_columns():
    header()
    console.print(Panel("[bold]Chart Columns[/]", border_style="#2e86c1", padding=(0,2)))
    console.print()

    config["label_col"] = Prompt.ask("  [#7f8c8d]Label column (X axis)          [/]", default=config["label_col"])
    config["bar_col"]   = Prompt.ask("  [#7f8c8d]Bar chart column               [/]", default=config["bar_col"])
    config["line_cols"] = Prompt.ask("  [#7f8c8d]Line chart columns (space-sep) [/]", default=config["line_cols"])
    config["max_rows"]  = IntPrompt.ask("  [#7f8c8d]Max table rows                 [/]", default=config["max_rows"])

    console.print()
    success_box("Chart columns updated.")
    time.sleep(1.0)


def menu_themes():
    header()
    console.print(Panel("[bold]Color Themes[/]", border_style="#2e86c1", padding=(0,2)))
    console.print()

    tbl = Table(box=box.ROUNDED, border_style="#1a3c5e", show_lines=True)
    tbl.add_column("#",        style="bold #f39c12", justify="center", width=4)
    tbl.add_column("Theme",    style="bold white",   width=12)
    tbl.add_column("Primary",  justify="center",     width=12)
    tbl.add_column("Secondary",justify="center",     width=12)
    tbl.add_column("Accent",   justify="center",     width=12)

    for k, v in THEMES.items():
        tbl.add_row(
            k,
            f"{v['icon']} {v['name']}",
            f"[{v['primary']}]██[/] {v['primary']}",
            f"[{v['secondary']}]██[/] {v['secondary']}",
            f"[{v['accent']}]██[/] {v['accent']}",
        )
    tbl.add_row("6", "✏️  Custom", "─", "─", "─")
    tbl.add_row("0", "Back",       "─", "─", "─")

    console.print(Align.center(tbl))
    console.print()

    choice = Prompt.ask("  [bold #2e86c1]Select theme[/]",
                        choices=[str(i) for i in range(7)], default="0")

    if choice in THEMES:
        t = THEMES[choice]
        config["primary"]   = t["primary"]
        config["secondary"] = t["secondary"]
        config["accent"]    = t["accent"]
        success_box(f"{t['icon']} {t['name']} theme applied!")
        time.sleep(1.0)
    elif choice == "6":
        console.print()
        config["primary"]   = Prompt.ask("  [#7f8c8d]Primary hex  [/]", default=config["primary"])
        config["secondary"] = Prompt.ask("  [#7f8c8d]Secondary hex[/]", default=config["secondary"])
        config["accent"]    = Prompt.ask("  [#7f8c8d]Accent hex   [/]", default=config["accent"])
        success_box("Custom colors saved.")
        time.sleep(1.0)


def run_report(demo_mode: bool = False):
    orig_demo = config["demo"]
    if demo_mode:
        config["demo"] = True

    if not config["demo"] and not config["data_file"]:
        error_box("No data file selected. Go to 'Data Source' or enable demo mode.")
        config["demo"] = orig_demo
        time.sleep(1.8)
        return

    console.print()
    show_command()
    console.print()

    if not Confirm.ask("  [bold #2e86c1]Run this command now?[/]", default=True):
        config["demo"] = orig_demo
        return

    console.print()
    loading_animation("Generating PDF report…", duration=1.5)

    # Build actual args list
    script = os.path.join(os.path.dirname(__file__), "report_generator.py")
    args = [sys.executable, script]

    if config["demo"]:
        args.append("--demo")
    elif config["data_file"]:
        args.append(config["data_file"])
    else:
        args.append("sales_data.csv")

    args += ["-o", config["output"],
             "-t", config["title"]]
    if config["subtitle"]:  args += ["-s",               config["subtitle"]]
    if config["author"]:    args += ["--author",          config["author"]]
    if config["company"]:   args += ["--company",         config["company"]]
    if config["label_col"]: args += ["--label-column",    config["label_col"]]
    if config["bar_col"]:   args += ["--bar-column",      config["bar_col"]]
    if config["line_cols"]: args += ["--line-columns"] + config["line_cols"].split()
    args += ["--max-rows",        str(config["max_rows"])]
    args += ["--primary-color",   config["primary"]]
    args += ["--secondary-color", config["secondary"]]
    args += ["--accent-color",    config["accent"]]

    try:
        result = subprocess.run(args, capture_output=True, text=True,
                                cwd=os.path.dirname(__file__))
        if result.returncode == 0:
            out = result.stdout.strip() or f"Report saved to: {config['output']}"
            success_box(f"[bold green]{escape(out)}[/]")
        else:
            error_box(f"Error:\n{escape(result.stderr.strip())}")
    except Exception as exc:
        error_box(f"Could not run script: {exc}")

    config["demo"] = orig_demo
    console.print()
    Prompt.ask("  [#7f8c8d]Press Enter to continue[/]", default="")


def menu_preview_command():
    header()
    show_command()
    console.print()
    Prompt.ask("  [#7f8c8d]Press Enter to go back[/]", default="")


# ─── Main menu ───────────────────────────────────────────────────────────────

def main_menu():
    while True:
        header()
        status_bar()

        # Menu table
        menu = Table(box=box.ROUNDED, border_style="#1a3c5e",
                     show_header=False, show_lines=True, expand=False, min_width=52)
        menu.add_column("key",  style="bold #f39c12", justify="center", width=5)
        menu.add_column("item", style="white",        width=34)
        menu.add_column("hint", style="#7f8c8d",      width=22)

        menu.add_row("1", "📁  Data Source",        "CSV / JSON / Demo")
        menu.add_row("2", "📝  Report Details",      "Title, author, output")
        menu.add_row("3", "📊  Chart Columns",       "Bar, line, labels")
        menu.add_row("4", "🎨  Color Theme",         "5 presets + custom")
        menu.add_row("5", "👁   Preview Command",    "Show CLI command")
        menu.add_row("─", "─" * 34, "─" * 22)
        menu.add_row("6", "⚡  Quick Demo",          "Run with demo data")
        menu.add_row("7", "🚀  Generate Report",     "Run full pipeline")
        menu.add_row("─", "─" * 34, "─" * 22)
        menu.add_row("0", "🚪  Exit",                "")

        console.print(Align.center(menu))
        console.print()

        choice = Prompt.ask("  [bold #2e86c1]Select option[/]",
                            choices=["0","1","2","3","4","5","6","7"],
                            default="7")

        if   choice == "1": menu_data_source()
        elif choice == "2": menu_report_details()
        elif choice == "3": menu_chart_columns()
        elif choice == "4": menu_themes()
        elif choice == "5": menu_preview_command()
        elif choice == "6": run_report(demo_mode=True)
        elif choice == "7": run_report(demo_mode=False)
        elif choice == "0":
            header()
            console.print(Align.center(
                Panel("[bold #2e86c1]Thanks for using PDF Report Generator![/]\n\n"
                      "[#7f8c8d]Run   [bold white]python report_generator.py --help[/]   for CLI docs.[/]",
                      border_style="#1a3c5e", padding=(1, 4))
            ))
            console.print()
            sys.exit(0)


# ─── Entry ───────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    # Splash loading screen
    clear()
    console.print()
    console.print(Align.center(Text("PDF Report Generator", style="bold #2e86c1 underline")))
    console.print(Align.center(Text("Starting up…", style="#7f8c8d")))
    console.print()

    with Progress(
        SpinnerColumn(spinner_name="dots2", style="#f39c12"),
        BarColumn(bar_width=40, style="#1a3c5e", complete_style="#2e86c1", finished_style="#27ae60"),
        TextColumn("[bold #5dade2]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task("Loading modules…", total=4)
        time.sleep(0.3); progress.update(task, advance=1, description="Checking dependencies…")
        time.sleep(0.3); progress.update(task, advance=1, description="Loading themes…")
        time.sleep(0.3); progress.update(task, advance=1, description="Ready!")
        time.sleep(0.3); progress.update(task, advance=1)

    main_menu()
