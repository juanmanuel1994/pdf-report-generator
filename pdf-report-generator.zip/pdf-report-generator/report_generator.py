"""
PDF Report Generator
Generates professional PDF reports from CSV or JSON data using ReportLab.
Includes cover page, formatted data table, bar/line charts, and executive summary.
"""

import csv
import json
import os
import sys
import argparse
from datetime import datetime
from typing import Optional

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.utils import ImageReader
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, HRFlowable, KeepTogether
)
from reportlab.platypus import Image as RLImage
from reportlab.graphics.shapes import Drawing, String
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.charts.linecharts import HorizontalLineChart
from reportlab.graphics import renderPDF


# ---------------------------------------------------------------------------
# Default theme
# ---------------------------------------------------------------------------

DEFAULT_THEME = {
    "primary":   colors.HexColor("#1a3c5e"),   # dark navy
    "secondary": colors.HexColor("#2e86c1"),   # medium blue
    "accent":    colors.HexColor("#f39c12"),   # amber
    "light":     colors.HexColor("#eaf4fb"),   # pale blue background
    "white":     colors.white,
    "text":      colors.HexColor("#2c3e50"),
    "muted":     colors.HexColor("#7f8c8d"),
}


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def load_csv(path: str) -> list[dict]:
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return [row for row in reader]


def load_json(path: str) -> list[dict]:
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, list):
        return data
    # Support {"data": [...]} wrapper
    for key in ("data", "records", "rows", "items"):
        if key in data and isinstance(data[key], list):
            return data[key]
    raise ValueError("JSON must be a list or an object with a 'data' key containing a list.")


def load_data(path: str) -> list[dict]:
    ext = os.path.splitext(path)[1].lower()
    if ext == ".csv":
        return load_csv(path)
    if ext == ".json":
        return load_json(path)
    raise ValueError(f"Unsupported file format: {ext}. Use .csv or .json")


# ---------------------------------------------------------------------------
# Summary statistics
# ---------------------------------------------------------------------------

def compute_summary(data: list[dict]) -> dict:
    """
    Auto-detect numeric columns and compute basic statistics.
    Returns a dict with per-column stats and detected column names.
    """
    if not data:
        return {}

    numeric_cols = []
    for col in data[0].keys():
        try:
            float(str(data[0][col]).replace(",", "").replace("$", ""))
            numeric_cols.append(col)
        except ValueError:
            pass

    summary = {}
    for col in numeric_cols:
        vals = []
        for row in data:
            try:
                vals.append(float(str(row[col]).replace(",", "").replace("$", "")))
            except (ValueError, KeyError):
                pass
        if vals:
            summary[col] = {
                "count": len(vals),
                "total": sum(vals),
                "mean":  sum(vals) / len(vals),
                "min":   min(vals),
                "max":   max(vals),
            }

    return summary


# ---------------------------------------------------------------------------
# Chart builders
# ---------------------------------------------------------------------------

def build_bar_chart(
    labels: list[str],
    values: list[float],
    title: str,
    theme: dict,
    width: float = 450,
    height: float = 220,
) -> Drawing:
    drawing = Drawing(width, height)

    chart = VerticalBarChart()
    chart.x = 50
    chart.y = 40
    chart.width = width - 70
    chart.height = height - 60
    chart.data = [values]
    chart.strokeColor = None
    chart.fillColor = None

    chart.bars[0].fillColor = theme["secondary"]
    chart.bars[0].strokeColor = theme["primary"]
    chart.bars[0].strokeWidth = 0.5

    chart.categoryAxis.categoryNames = [str(l)[:12] for l in labels]
    chart.categoryAxis.labels.fontName = "Helvetica"
    chart.categoryAxis.labels.fontSize = 7
    chart.categoryAxis.labels.angle = 30 if len(labels) > 6 else 0
    chart.categoryAxis.labels.dy = -8
    chart.categoryAxis.strokeColor = theme["muted"]
    chart.categoryAxis.gridStrokeColor = colors.HexColor("#dce6ee")

    chart.valueAxis.labels.fontName = "Helvetica"
    chart.valueAxis.labels.fontSize = 7
    chart.valueAxis.strokeColor = theme["muted"]
    chart.valueAxis.gridStrokeColor = colors.HexColor("#dce6ee")
    chart.valueAxis.gridStrokeDashArray = [2, 2]

    drawing.add(chart)

    title_label = String(width / 2, height - 10, title,
                         fontName="Helvetica-Bold", fontSize=9,
                         fillColor=theme["primary"], textAnchor="middle")
    drawing.add(title_label)

    return drawing


def build_line_chart(
    labels: list[str],
    series: list[tuple[str, list[float]]],
    title: str,
    theme: dict,
    width: float = 450,
    height: float = 220,
) -> Drawing:
    drawing = Drawing(width, height)

    chart = HorizontalLineChart()
    chart.x = 50
    chart.y = 40
    chart.width = width - 70
    chart.height = height - 60
    chart.data = [s[1] for s in series]
    chart.joinedLines = 1

    line_colors = [theme["secondary"], theme["accent"], theme["primary"],
                   colors.HexColor("#27ae60"), colors.HexColor("#8e44ad")]
    for i, (name, _) in enumerate(series):
        c = line_colors[i % len(line_colors)]
        chart.lines[i].strokeColor = c
        chart.lines[i].strokeWidth = 2
        chart.lines[i].symbol = None

    chart.categoryAxis.categoryNames = [str(l)[:12] for l in labels]
    chart.categoryAxis.labels.fontName = "Helvetica"
    chart.categoryAxis.labels.fontSize = 7
    chart.categoryAxis.labels.angle = 30 if len(labels) > 6 else 0
    chart.categoryAxis.labels.dy = -8
    chart.categoryAxis.strokeColor = theme["muted"]

    chart.valueAxis.labels.fontName = "Helvetica"
    chart.valueAxis.labels.fontSize = 7
    chart.valueAxis.strokeColor = theme["muted"]
    chart.valueAxis.gridStrokeDashArray = [2, 2]

    drawing.add(chart)

    title_label = String(width / 2, height - 10, title,
                         fontName="Helvetica-Bold", fontSize=9,
                         fillColor=theme["primary"], textAnchor="middle")
    drawing.add(title_label)

    return drawing


# ---------------------------------------------------------------------------
# PDF builder
# ---------------------------------------------------------------------------

class ReportBuilder:
    def __init__(
        self,
        output_path: str,
        title: str = "Sales Report",
        subtitle: str = "",
        logo_path: Optional[str] = None,
        theme: Optional[dict] = None,
        page_size=letter,
        author: str = "Report Generator",
        company: str = "",
    ):
        self.output_path = output_path
        self.title = title
        self.subtitle = subtitle
        self.logo_path = logo_path
        self.theme = theme or DEFAULT_THEME
        self.page_size = page_size
        self.author = author
        self.company = company
        self.story: list = []

        self.doc = SimpleDocTemplate(
            output_path,
            pagesize=page_size,
            leftMargin=0.75 * inch,
            rightMargin=0.75 * inch,
            topMargin=0.75 * inch,
            bottomMargin=0.75 * inch,
            title=title,
            author=author,
        )
        self._build_styles()

    def _build_styles(self):
        base = getSampleStyleSheet()
        t = self.theme

        self.styles = {
            "cover_title": ParagraphStyle(
                "cover_title",
                fontName="Helvetica-Bold",
                fontSize=32,
                textColor=t["white"],
                spaceAfter=12,
                leading=38,
                alignment=1,
            ),
            "cover_subtitle": ParagraphStyle(
                "cover_subtitle",
                fontName="Helvetica",
                fontSize=16,
                textColor=colors.HexColor("#bdc3c7"),
                spaceAfter=6,
                leading=22,
                alignment=1,
            ),
            "cover_meta": ParagraphStyle(
                "cover_meta",
                fontName="Helvetica",
                fontSize=11,
                textColor=colors.HexColor("#95a5a6"),
                alignment=1,
            ),
            "section_heading": ParagraphStyle(
                "section_heading",
                fontName="Helvetica-Bold",
                fontSize=14,
                textColor=t["primary"],
                spaceBefore=18,
                spaceAfter=6,
                borderPad=4,
            ),
            "body": ParagraphStyle(
                "body",
                fontName="Helvetica",
                fontSize=10,
                textColor=t["text"],
                spaceAfter=6,
                leading=15,
            ),
            "body_bold": ParagraphStyle(
                "body_bold",
                fontName="Helvetica-Bold",
                fontSize=10,
                textColor=t["text"],
                spaceAfter=4,
            ),
            "table_header": ParagraphStyle(
                "table_header",
                fontName="Helvetica-Bold",
                fontSize=9,
                textColor=t["white"],
            ),
            "table_cell": ParagraphStyle(
                "table_cell",
                fontName="Helvetica",
                fontSize=9,
                textColor=t["text"],
            ),
            "kpi_value": ParagraphStyle(
                "kpi_value",
                fontName="Helvetica-Bold",
                fontSize=22,
                textColor=t["secondary"],
                alignment=1,
            ),
            "kpi_label": ParagraphStyle(
                "kpi_label",
                fontName="Helvetica",
                fontSize=9,
                textColor=t["muted"],
                alignment=1,
            ),
            "footer": ParagraphStyle(
                "footer",
                fontName="Helvetica",
                fontSize=8,
                textColor=t["muted"],
                alignment=1,
            ),
        }

    # ------------------------------------------------------------------
    # Cover page
    # ------------------------------------------------------------------

    def add_cover(self):
        t = self.theme
        w, h = self.page_size

        # Full-bleed background rectangle via a Table trick
        bg_data = [[""]]
        bg_table = Table(bg_data, colWidths=[w - 1.5 * inch], rowHeights=[h * 0.55])
        bg_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), t["primary"]),
            ("BOX",        (0, 0), (-1, -1), 0, t["primary"]),
        ]))

        cover_items = []

        # Logo (if provided)
        if self.logo_path and os.path.isfile(self.logo_path):
            logo = RLImage(self.logo_path, width=1.5 * inch, height=1.5 * inch,
                           kind="proportional")
            logo.hAlign = "CENTER"
            cover_items.append(logo)
            cover_items.append(Spacer(1, 0.2 * inch))

        cover_items += [
            Spacer(1, 0.6 * inch),
            Paragraph(self.title, self.styles["cover_title"]),
        ]

        if self.subtitle:
            cover_items.append(Paragraph(self.subtitle, self.styles["cover_subtitle"]))

        cover_items += [
            Spacer(1, 0.3 * inch),
            HRFlowable(width="60%", thickness=1, color=t["accent"], hAlign="CENTER"),
            Spacer(1, 0.3 * inch),
        ]

        if self.company:
            cover_items.append(Paragraph(self.company, self.styles["cover_meta"]))

        cover_items.append(
            Paragraph(
                f"Generated on {datetime.now().strftime('%B %d, %Y')}",
                self.styles["cover_meta"],
            )
        )
        cover_items.append(Paragraph(f"Prepared by: {self.author}", self.styles["cover_meta"]))

        self.story += cover_items
        self.story.append(PageBreak())

    # ------------------------------------------------------------------
    # Section heading
    # ------------------------------------------------------------------

    def add_section(self, title: str):
        t = self.theme
        self.story.append(Spacer(1, 0.1 * inch))
        self.story.append(
            HRFlowable(width="100%", thickness=2, color=t["accent"], spaceAfter=4)
        )
        self.story.append(Paragraph(title, self.styles["section_heading"]))

    # ------------------------------------------------------------------
    # KPI cards row
    # ------------------------------------------------------------------

    def add_kpi_row(self, kpis: list[tuple[str, str]]):
        """kpis = [(label, value), ...]"""
        t = self.theme
        n = len(kpis)
        if n == 0:
            return

        w, _ = self.page_size
        avail = w - 1.5 * inch
        col_w = avail / n

        cells = []
        for label, value in kpis:
            cell = [
                Paragraph(value, self.styles["kpi_value"]),
                Paragraph(label, self.styles["kpi_label"]),
            ]
            cells.append(cell)

        tbl = Table([cells], colWidths=[col_w] * n, rowHeights=[0.9 * inch])
        tbl.setStyle(TableStyle([
            ("BACKGROUND",  (0, 0), (-1, -1), t["light"]),
            ("BOX",         (0, 0), (-1, -1), 1, t["secondary"]),
            ("LINEAFTER",   (0, 0), (-2, -1), 0.5, t["secondary"]),
            ("VALIGN",      (0, 0), (-1, -1), "MIDDLE"),
            ("ALIGN",       (0, 0), (-1, -1), "CENTER"),
            ("TOPPADDING",  (0, 0), (-1, -1), 10),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ]))
        self.story.append(tbl)
        self.story.append(Spacer(1, 0.15 * inch))

    # ------------------------------------------------------------------
    # Data table
    # ------------------------------------------------------------------

    def add_data_table(self, data: list[dict], max_rows: int = 50):
        if not data:
            self.story.append(Paragraph("No data available.", self.styles["body"]))
            return

        t = self.theme
        columns = list(data[0].keys())
        rows = data[:max_rows]

        w, _ = self.page_size
        avail = w - 1.5 * inch
        col_w = avail / len(columns)

        header = [Paragraph(c.replace("_", " ").title(), self.styles["table_header"])
                  for c in columns]
        table_data = [header]

        for i, row in enumerate(rows):
            table_data.append([
                Paragraph(str(row.get(c, "")), self.styles["table_cell"])
                for c in columns
            ])

        style = TableStyle([
            ("BACKGROUND",    (0, 0), (-1, 0),  t["primary"]),
            ("ROWBACKGROUNDS",(0, 1), (-1, -1), [t["white"], t["light"]]),
            ("GRID",          (0, 0), (-1, -1), 0.4, colors.HexColor("#c8d8e8")),
            ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
            ("ALIGN",         (0, 0), (-1, -1), "CENTER"),
            ("TOPPADDING",    (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ("LEFTPADDING",   (0, 0), (-1, -1), 6),
            ("RIGHTPADDING",  (0, 0), (-1, -1), 6),
        ])

        tbl = Table(table_data, colWidths=[col_w] * len(columns), repeatRows=1)
        tbl.setStyle(style)
        self.story.append(tbl)

        if len(data) > max_rows:
            self.story.append(
                Paragraph(
                    f"<i>Showing {max_rows} of {len(data)} rows.</i>",
                    self.styles["body"],
                )
            )
        self.story.append(Spacer(1, 0.15 * inch))

    # ------------------------------------------------------------------
    # Charts
    # ------------------------------------------------------------------

    def add_bar_chart(self, labels, values, title="Bar Chart"):
        chart = build_bar_chart(labels, values, title, self.theme)
        self.story.append(chart)
        self.story.append(Spacer(1, 0.15 * inch))

    def add_line_chart(self, labels, series, title="Line Chart"):
        chart = build_line_chart(labels, series, title, self.theme)
        self.story.append(chart)
        self.story.append(Spacer(1, 0.15 * inch))

    # ------------------------------------------------------------------
    # Executive summary
    # ------------------------------------------------------------------

    def add_executive_summary(self, data: list[dict], summary: dict):
        self.add_section("Executive Summary")

        total_records = len(data)
        self.story.append(
            Paragraph(
                f"This report covers <b>{total_records}</b> records. "
                "Below is a statistical overview of the key numeric indicators.",
                self.styles["body"],
            )
        )
        self.story.append(Spacer(1, 0.1 * inch))

        if not summary:
            self.story.append(Paragraph("No numeric columns detected.", self.styles["body"]))
            return

        t = self.theme
        header = [
            Paragraph("Metric",   self.styles["table_header"]),
            Paragraph("Count",    self.styles["table_header"]),
            Paragraph("Total",    self.styles["table_header"]),
            Paragraph("Average",  self.styles["table_header"]),
            Paragraph("Min",      self.styles["table_header"]),
            Paragraph("Max",      self.styles["table_header"]),
        ]
        rows = [header]
        for col, stats in summary.items():
            rows.append([
                Paragraph(col.replace("_", " ").title(), self.styles["table_cell"]),
                Paragraph(f"{stats['count']:,}",              self.styles["table_cell"]),
                Paragraph(f"{stats['total']:,.2f}",           self.styles["table_cell"]),
                Paragraph(f"{stats['mean']:,.2f}",            self.styles["table_cell"]),
                Paragraph(f"{stats['min']:,.2f}",             self.styles["table_cell"]),
                Paragraph(f"{stats['max']:,.2f}",             self.styles["table_cell"]),
            ])

        w, _ = self.page_size
        avail = w - 1.5 * inch
        col_widths = [avail * r for r in [0.30, 0.12, 0.16, 0.16, 0.13, 0.13]]

        tbl = Table(rows, colWidths=col_widths, repeatRows=1)
        tbl.setStyle(TableStyle([
            ("BACKGROUND",    (0, 0), (-1, 0),  t["primary"]),
            ("ROWBACKGROUNDS",(0, 1), (-1, -1), [t["white"], t["light"]]),
            ("GRID",          (0, 0), (-1, -1), 0.4, colors.HexColor("#c8d8e8")),
            ("ALIGN",         (1, 0), (-1, -1), "RIGHT"),
            ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
            ("TOPPADDING",    (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ("LEFTPADDING",   (0, 0), (-1, -1), 6),
            ("RIGHTPADDING",  (0, 0), (-1, -1), 6),
        ]))
        self.story.append(tbl)
        self.story.append(Spacer(1, 0.15 * inch))

    # ------------------------------------------------------------------
    # Footer callback
    # ------------------------------------------------------------------

    def _footer(self, canvas, doc):
        canvas.saveState()
        t = self.theme
        w, h = self.page_size
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(t["muted"])
        canvas.drawString(0.75 * inch, 0.4 * inch, self.title)
        canvas.drawRightString(
            w - 0.75 * inch, 0.4 * inch,
            f"Page {doc.page}  |  {datetime.now().strftime('%Y-%m-%d')}",
        )
        canvas.setStrokeColor(t["accent"])
        canvas.setLineWidth(0.5)
        canvas.line(0.75 * inch, 0.55 * inch, w - 0.75 * inch, 0.55 * inch)
        canvas.restoreState()

    # ------------------------------------------------------------------
    # Build
    # ------------------------------------------------------------------

    def build(self):
        self.doc.build(self.story, onFirstPage=self._footer, onLaterPages=self._footer)
        print(f"Report saved to: {self.output_path}")


# ---------------------------------------------------------------------------
# High-level generate function
# ---------------------------------------------------------------------------

def generate_report(
    data_path: str,
    output_path: str = "report.pdf",
    title: str = "Sales Report",
    subtitle: str = "Annual Performance Overview",
    logo_path: Optional[str] = None,
    primary_color: Optional[str] = None,
    secondary_color: Optional[str] = None,
    accent_color: Optional[str] = None,
    author: str = "Report Generator",
    company: str = "",
    label_column: Optional[str] = None,
    bar_column: Optional[str] = None,
    line_columns: Optional[list[str]] = None,
    max_table_rows: int = 50,
):
    data = load_data(data_path)
    if not data:
        print("Error: dataset is empty.")
        sys.exit(1)

    theme = dict(DEFAULT_THEME)
    if primary_color:
        theme["primary"]   = colors.HexColor(primary_color)
    if secondary_color:
        theme["secondary"] = colors.HexColor(secondary_color)
    if accent_color:
        theme["accent"]    = colors.HexColor(accent_color)

    builder = ReportBuilder(
        output_path=output_path,
        title=title,
        subtitle=subtitle,
        logo_path=logo_path,
        theme=theme,
        author=author,
        company=company,
    )

    # --- Cover ---
    builder.add_cover()

    # --- Detect columns ---
    columns = list(data[0].keys())
    summary = compute_summary(data)
    numeric_cols = list(summary.keys())

    # Label column: first non-numeric column, or override
    if label_column and label_column in columns:
        lbl_col = label_column
    else:
        lbl_col = next((c for c in columns if c not in numeric_cols), columns[0])

    labels = [str(row.get(lbl_col, i)) for i, row in enumerate(data)]

    # --- KPI cards ---
    if numeric_cols:
        kpis = []
        for col in numeric_cols[:4]:
            total = summary[col]["total"]
            kpis.append((col.replace("_", " ").title(), f"{total:,.0f}"))
        builder.add_section("Key Performance Indicators")
        builder.add_kpi_row(kpis)

    # --- Bar chart ---
    builder.add_section("Data Overview")
    bar_col = bar_column if bar_column in numeric_cols else (numeric_cols[0] if numeric_cols else None)
    if bar_col:
        bar_vals = []
        for row in data:
            try:
                bar_vals.append(float(str(row.get(bar_col, 0)).replace(",", "").replace("$", "")))
            except ValueError:
                bar_vals.append(0.0)
        builder.add_bar_chart(labels, bar_vals, f"{bar_col.replace('_',' ').title()} by {lbl_col.replace('_',' ').title()}")

    # --- Line chart ---
    if line_columns:
        lc = [c for c in line_columns if c in numeric_cols]
    else:
        lc = numeric_cols[:3]

    if lc:
        series = []
        for col in lc:
            vals = []
            for row in data:
                try:
                    vals.append(float(str(row.get(col, 0)).replace(",", "").replace("$", "")))
                except ValueError:
                    vals.append(0.0)
            series.append((col, vals))
        builder.add_line_chart(labels, series, "Trends Over Time")

    # --- Data table ---
    builder.add_section("Data Table")
    builder.add_data_table(data, max_rows=max_table_rows)

    # --- Executive summary ---
    builder.add_executive_summary(data, summary)

    builder.build()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Generate a professional PDF report from CSV or JSON data."
    )
    parser.add_argument("data", nargs="?", default=None, help="Path to CSV or JSON data file (not needed with --demo)")
    parser.add_argument("-o", "--output",     default="report.pdf",    help="Output PDF path (default: report.pdf)")
    parser.add_argument("-t", "--title",      default="Sales Report",  help="Report title")
    parser.add_argument("-s", "--subtitle",   default="",              help="Report subtitle")
    parser.add_argument("--logo",             default=None,            help="Path to logo image (PNG/JPG)")
    parser.add_argument("--author",           default="Report Generator", help="Author name")
    parser.add_argument("--company",          default="",              help="Company name")
    parser.add_argument("--primary-color",    default=None,            help="Primary color hex (e.g. #1a3c5e)")
    parser.add_argument("--secondary-color",  default=None,            help="Secondary color hex")
    parser.add_argument("--accent-color",     default=None,            help="Accent color hex")
    parser.add_argument("--label-column",     default=None,            help="Column to use as category labels")
    parser.add_argument("--bar-column",       default=None,            help="Numeric column for bar chart")
    parser.add_argument("--line-columns",     default=None, nargs="+", help="Numeric columns for line chart")
    parser.add_argument("--max-rows",         default=50, type=int,    help="Max rows to show in data table (default: 50)")
    parser.add_argument("--demo",             action="store_true",     help="Run with built-in demo dataset")

    args = parser.parse_args()

    if args.demo:
        demo_path = os.path.join(os.path.dirname(__file__), "sales_data.csv")
        if not os.path.isfile(demo_path):
            print("Demo dataset not found. Run from the project directory.")
            sys.exit(1)
        generate_report(
            data_path=demo_path,
            output_path=args.output,
            title="Annual Sales Report 2024",
            subtitle="Q1–Q4 Performance Overview",
            author="Sales Analytics Team",
            company="Acme Corporation",
        )
    else:
        if not args.data:
            parser.error("the following arguments are required: data (or use --demo)")
        generate_report(
            data_path=args.data,
            output_path=args.output,
            title=args.title,
            subtitle=args.subtitle,
            logo_path=args.logo,
            primary_color=args.primary_color,
            secondary_color=args.secondary_color,
            accent_color=args.accent_color,
            author=args.author,
            company=args.company,
            label_column=args.label_column,
            bar_column=args.bar_column,
            line_columns=args.line_columns,
            max_table_rows=args.max_rows,
        )


if __name__ == "__main__":
    main()
